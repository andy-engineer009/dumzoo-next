export const USER_ROLES = {
    hasVisitedBefore: 'hasVisitedBefore', // first time user role checker 
    isLoggedIn: 'isLoggedIn', // user login checker login or logout
    userRole: 'userRole', // user role checker 


    WZRK_LR : 'WZRK_LR', // check user loggind or not loggied  
    cto_bundle: 'cto_bundle', // check user role,
    google_cache: 'google_cache', // token 
    
}