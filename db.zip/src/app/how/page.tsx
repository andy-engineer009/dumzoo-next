import AppPromotionPage from "@/components/how/app-promotion-page";

export default function How() {
  return (
    <div>
      <AppPromotionPage />          
    </div>
  );
}
