import BoosterPlan from "@/components/Plans";

export default function Booster() {
  return (
    <div>
      <BoosterPlan />
    </div>
  );
}
