import CampaignsDiscover from "@/components/discover/campaigns";

export default function CampaignsPage() {    
    return (
        <>
        <CampaignsDiscover />
        </>
    )
}
