import InfluencerOnboardingForm from '@/components/influencer/InfluencerOnboardingForm';

export default function RegistrationPage() {
  return <InfluencerOnboardingForm />;
} 