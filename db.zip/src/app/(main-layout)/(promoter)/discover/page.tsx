import InfluencerDiscover from "@/components/discover/influencer";

export default function Discover() {
    return <>
    <InfluencerDiscover />
    </>;
}