import CampaignsList from "@/components/campaigns/manage-campaigns-list";

export default function ManageCampaign() {
    return (
        <div>
            <CampaignsList />
        </div>
    )
}