import CampaignAppliedInfulnacerList from "@/components/campaigns/campaign-applied-infulnacer-list";

    export default function CampaignDetails() {
    return (
        <div>
            <CampaignAppliedInfulnacerList />
        </div>
    )
}