import CampaignsCreate from "@/components/campaigns/campaignsCreate";

export default function AddCampaign() {
    return (
        <div>
            <CampaignsCreate />
        </div>
    )
}