import Profile from '@/components/profile';

export default function ProfilePage() {
  return <Profile />;
}   