import ViewProfile from "@/components/influencer/profile/view-profile";

export default function ViewProfilePage() {
    return (
        <div>
            {/* <h1>View Profile</h1> */}
            <ViewProfile />
        </div>
    )
}