import EditBasicDetails from "@/components/influencer/profile/Basic-details";

export default function EditBasicDetailsPage() {
    return <EditBasicDetails />
}