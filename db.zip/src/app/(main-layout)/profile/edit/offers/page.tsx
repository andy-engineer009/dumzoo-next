import EditOffers from "@/components/influencer/profile/Offers";

export default function EditOffersPage() {
    return <EditOffers />
}