import MediaForm from "@/components/influencer/profile/Media";

export default function MediaPage() {
    return <MediaForm />
}