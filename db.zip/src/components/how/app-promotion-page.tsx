// Add this route to your Next.js app
// pages/intro.tsx or app/intro/page.tsx
import PlatformIntroduction from '@/components/how/PlatformIntroduction';

export default function IntroPage() {
  return <PlatformIntroduction />;
}